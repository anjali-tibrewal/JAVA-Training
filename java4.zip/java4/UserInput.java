import java.io.*;
class UserInput
{
	public static void main(String ar[])throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String s;
		System.out.println("Enter your name:");
		try{
			s=br.readLine();
		}
		catch(IOException e)
		{
			System.out.println("error");
		}
		System.out.println("hello, "+s);	}
}