class forEach
{
	public void dis()
	{
		int x[]={1,3,5};
		//x[3]={1,3,5};
		
		for(int i:x)
		{
			System.out.println(i);
		}
	}
	public static void main(String ar[])
	{
		forEach f1=new forEach();
		f1.dis();
	}
}