import java.io.*;

class DIOS
{
  void change() throws IOException
  {
     
         FileOutputStream f=new FileOutputStream("primitive.txt");
         DataOutputStream d=new DataOutputStream(f);
    
         float a=(float)20.33;
         d.writeBoolean(true);
         d.writeChar('a');
         d.writeInt(10);
         d.writeFloat((float)100.20);
         d.writeByte(12);
         d.close();
     
  }
  void disp() throws IOException
  {
     
         FileInputStream fi=new FileInputStream("primitive.txt");
         DataInputStream di=new DataInputStream(fi);

         boolean b=di.readBoolean();
         char c=di.readChar();
         int i=di.readInt();
         float fl=di.readFloat();
         byte by=di.readByte();
          
         System.out.println(b);
         System.out.println(c);
         System.out.println(i);
         System.out.println(fl);
         System.out.println(by);
    
         di.close();
     
      
     
  }
  public static void main(String args[])
  {
       DIOS e=new DIOS();
      try
      {
         e.disp();
         e.change();  
      }
     catch(IOException ae)
     {
         System.out.println("error"); 
     }       

  }
}