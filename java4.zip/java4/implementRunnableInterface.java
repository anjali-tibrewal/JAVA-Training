class demo implements Runnable
{
	int i;
	public void run()
	{
		for(i=0;i<5;i++)
		{
			System.out.println("child"+(i+1));
			System.out.println("child"+(i+1)+"finished");
		}
	}
	
}
class implementRunnableInterface
{
	public static void main(String ar[]){
	demo d=new demo();
	demo d1=new demo();
	Thread t=new Thread(d);
	Thread t1=new Thread(d1);
	t.start();
	t1.start();
	}
}