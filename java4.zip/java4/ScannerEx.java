import java.util.Scanner;

class ScannerEx
{
   int x=29;
  
   public static void main(String args[])
   {
    
        Scanner sc=new Scanner(System.in);
        System.out.println("enter your name");
        String s1=sc.next();
        System.out.println("s1="+s1);
        System.out.println("enter your age");
        int s2=sc.nextInt();
        System.out.println("s2="+s2);
        System.out.println("enter the value in byte");
        byte s3=sc.nextByte();
        System.out.println("s3="+s3);
        System.out.println("enter any char");
        String s4=sc.next();
        System.out.println("s4="+s4);
    }
}