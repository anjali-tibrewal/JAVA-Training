class demo extends Thread
{
	int i;
	demo()
	{
		start();
	}
	public void run()
	{
		for(i=0;i<5;i++)
		{
			System.out.println("child"+(i+1));
			System.out.println("child"+(i+1)+"finished");
		}
	}
	
}
class extendThreadClass
{
	public static void main(String ar[])
	{
		demo d=new demo();
		demo d1=new demo();
	
	}
}