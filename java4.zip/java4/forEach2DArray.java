class forEach2DArray
{
	public void dis()
	{
		int x[][]=new int[3][];
		
		
		x[0]=new int[] {1,2,3,4};
		x[1]=new int[] {5,6};
		x[2]=new int[] {5,7,6};
		for(int i[]:x)
		{
			for(int j:i)
				System.out.print(j+",");
			System.out.println();
		}
	}
	public static void main(String ar[])
	{
		forEach2DArray f1=new forEach2DArray();
		f1.dis();
	}
}