class demo implements Runnable
{
	int i;
	
	public void run()
	{
		
		show();
	}
	synchronized public void show()
	{
		{
			System.out.println("child");
			try
			
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
				System.out.println("interrupted");
			}
			System.out.println("child finished");
		}
	}
	
}
class useSynchronizedRunnable
{
	public static void main(String ar[])
	{
		demo d=new demo();
		//demo d1=new demo();
		Thread t=new Thread(d);
		Thread t2=new Thread(d);
		t.start();
		t2.start();
	
	}
}