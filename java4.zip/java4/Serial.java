import java.io.*;

class A implements Serializable
{
    void show()
    {
          System.out.println("class A");
    }
}
class Serial
{
    A a1;
    void writeData()
    {
       try
       {
           FileOutputStream f=new FileOutputStream("Serial.txt");
           ObjectOutputStream os=new ObjectOutputStream(f);

           String s[]={"hello","world"};
           int x=10;
           int []y={12,123,12};
   
           os.writeObject(s);
           os.writeInt(x);
           os.writeObject(y);
           a1=new A();
           os.writeObject(a1);
           os.close();
       }
       catch(IOException e)
       {
           System.out.println("error");
       }
    }
    void readData()
    {
       try
       {
           FileInputStream fo=new FileInputStream("Serial.txt");
           ObjectInputStream oi=new ObjectInputStream(fo);
           String s1[]=(String[])oi.readObject();

           for(int i=0;i<s1.length;i++)
           System.out.println(s1[i]);

           int p=oi.readInt();
           System.out.println(p);

           int y1[]=(int[])oi.readObject();
           for(int i=0;i<s1.length;i++)
           System.out.println(y1[i]);

           a1=(A)oi.readObject();
           a1.show();
           oi.close();
        }
        catch(Exception e)
       {
           System.out.println("error");
       }
    }
    public static void main(String args[])
    {
          Serial s=new Serial();
          s.writeData();
          s.readData();
    }
}