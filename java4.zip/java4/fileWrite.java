import java.io.*;
class A
{
	int i;
	FileInputStream f;
	FileOutputStream fo;
	void read()throws IOException
	{
		try{
			fo=new FileOutputStream("File2.txt");
			f=new FileInputStream("File2.txt");
		}
		catch(FileNotFoundException f)
		{
			System.out.println("error");
		}
		String s="Anjali Tibrewal";
		byte b[]=s.getBytes();
		fo.write(b);
		do
		{
			i=f.read();
			if(i!=-1)
				System.out.println((char)i);
		}while(i!=-1);
	}
}
class fileWrite
{
	public static void main(String ar[])
	{
		A a1=new A();
		try{
			a1.read();
		}
		catch(IOException e)
		{
			System.out.println("error");
		}	
		
	}
	}
	