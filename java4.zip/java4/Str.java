class Str
{
	public static void main(String ar[])
	{
		String s1="hello";
		String s="hello";
		String s2=new String("hello");
		String s3=new String("hello");
		StringBuilder sb=new StringBuilder("hello world");
		sb=sb.delete(4,8);
		System.out.println("after delete sb="+sb);
		sb=sb.append(s);
		System.out.println("after append sb="+sb);
		System.out.println("s1==s2"+(s1==s2));
		System.out.println("s==s1"+(s==s1));
		System.out.println("s2==s3"+(s2==s3));
		//System.out.println("s.equals(sb)"+(s==sb));
		System.out.println("s.equlas(s1)"+s.equals(sb));
	}
}