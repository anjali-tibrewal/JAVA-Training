import java.io.*;
class Freader
{
  static int i;
  FileReader f;
   void display() throws IOException
  { 
     try
    	{
       		f = new FileReader("fine1.txt");
    	}
    	catch(FileNotFoundException e)
   	{
        	System.out.println("Error");
    	}
    	do
    	{
      		i=f.read();
      		if(i!=-1)
        		  System.out.println((char)i);
    	}while(i!=-1);
  }
  public static void main(String args[])
  {
   
    Freader b=new Freader();
    try
    {
         b.display();
    }
    
    catch(IOException e)
    {
        System.out.println("Error");
    }
  }
}