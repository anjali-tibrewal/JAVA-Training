class demo extends Thread
{
	int i;
	demo()
	{
		start();
	}
	public void run()
	{
		for(i=0;i<5;i++)
		{
			System.out.println("child"+(i+1));
			try
			
			{
				sleep(1000);
			}
			catch(InterruptedException e)
			{
				System.out.println("interrupted");
			}
			System.out.println("child"+(i+1)+"finished");
		}
	}
	
}
class useSleep
{
	public static void main(String ar[])
	{
		demo d=new demo();
		demo d1=new demo();
	
	}
}