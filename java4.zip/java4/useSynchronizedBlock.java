class A
{
	public void show()
		{
			{
				System.out.println("child");
				try
			
				{
					Thread.sleep(10000);
				}
				catch(InterruptedException e)
				{
					System.out.println("interrupted");
				}
				System.out.println("child finished");
			}
		}
		public void add()
		{
			System.out.println("add()");
		}
}
class demo implements Runnable
{
	int i;
	A a;
	demo(A a)
	{
		this.a=a;
	}
	
	public void run()
	{
		
		synchronized(a)
		{
				a.show();
			a.add();
		
		}
	}
	
}
class useSynchronizedBlock
{
	public static void main(String ar[])
	{
		A a1=new A();
		demo d=new demo(a1);
		//demo d1=new demo();
		Thread t=new Thread(d);
		Thread t2=new Thread(d);
		t.start();
		t2.start();
	}
}