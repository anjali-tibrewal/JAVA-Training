import java.io.*;
class A
{
	int i;
	FileInputStream f;
	FileOutputStream fo;
	FileInputStream f3;
	void read()throws IOException
	{
		try{
			fo=new FileOutputStream("File2.txt");
			f=new FileInputStream("File1.txt");
			//f3=new FileInputStream("File2.txt");
		}
		catch(FileNotFoundException fe)
		{
			System.out.println("error");
		}
		//String s="Anjali Tibrewal";
		//byte b[]=s.getBytes();
		//fo.write(b);
		do
		{
			i=f.read();
			if(i!=-1)
				fo.write((char)i);
		}while(i!=-1);
		
	}
	void show()throws IOException
	{
		//FileInputStream f3;
		try{
			f3=new FileInputStream("File2.txt");
		}
		catch(FileNotFoundException fe)
		{
			System.out.println("error");
		}

		
	


		System.out.println("Contents from 2nd file are");
		
		do
		{
			i=f3.read();
			if(i!=-1)
				System.out.println((char)i);
		}while(i!=-1);
	}
}
class copyContents
{
	public static void main(String ar[])
	{
		A a1=new A();
		try{
			a1.read();
			a1.show();
		}
		catch(IOException e)
		{
			System.out.println("error");
		}	
		
	}
	}
	